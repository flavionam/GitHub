﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarrinhoCompras.Models.Model
{
    public class PedidoModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [EmailAddress] 
        public string Email { get; set; }

        public string Item1 { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Favor digitar uma quantidade válida.")]
        public int QtdeItem1 { get; set; }

        public string Item2 { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Favor digitar uma quantidade válida.")]
        public int QtdeItem2 { get; set; }

    }
}