﻿using CarrinhoCompras.Models.Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarrinhoCompras.Controllers
{
    public class ResumoController : Controller
    {

        public ActionResult Index(int id)
        {
            var pedido = new PedidoNeg().GetById(id);
            return View(pedido);
        }
       



    }
}