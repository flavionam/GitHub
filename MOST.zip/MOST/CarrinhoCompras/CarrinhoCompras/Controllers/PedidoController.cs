﻿using CarrinhoCompras.Models.Model;
using CarrinhoCompras.Models.Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarrinhoCompras.Controllers
{
    public class PedidoController : Controller
    {
        // GET: Pedido
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Cadastrar(PedidoModel pedido)
        {
            try
            {
                new PedidoNeg().Cadastrar(pedido);
                
                return Listar();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        public ActionResult Listar()
        {
            var listaPedidos = new PedidoNeg().Listar();
            return Json(listaPedidos, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Editar(int id)
        {
            try
            {
                var pedido = new PedidoNeg().GetById(id);
                return Json(pedido, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult Atualizar(PedidoModel pedido)
        {
            try
            {
                new PedidoNeg().Atualizar(pedido);

                return Listar();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult Deletar(int id)
        {
            try
            {
                new PedidoNeg().Deletar(id);

                return Listar();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void EnviarEmail(int id)
        {
            try
            {
                new PedidoNeg().EnviarEmail(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public PedidoModel Buscar(int id)
        {
            try
            {
                return new PedidoNeg().GetById(id);
            }
            catch (Exception)
            {
                throw;
            }
        }



    }
}