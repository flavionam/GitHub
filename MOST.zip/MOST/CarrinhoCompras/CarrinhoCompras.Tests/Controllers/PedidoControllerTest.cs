﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CarrinhoCompras.Controllers;
using System.Web.Mvc;
using CarrinhoCompras.Models.Negocio;
using CarrinhoCompras.Models.Model;
using System.Web.Script.Serialization;
using System.Dynamic;

namespace CarrinhoCompras.Tests.Controllers
{
    [TestClass]
    public class PedidoControllerTest
    {
      

        [TestMethod]
        public void Index()
        {
            // Arrange
            PedidoController controller = new PedidoController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void CadastrarPedido()
        {
            try
            {
                var pedido = CriaMockPedido();

                new PedidoNeg().Cadastrar(pedido);

                PedidoController controller = new PedidoController();

                // Act
                var actual = controller.Buscar(pedido.Id);

                // Assert
                Assert.AreEqual(actual.Id, pedido.Id);

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [TestMethod]
        public void AtualizarPedido()
        {
            try
            {
                var pedido = CriaMockPedido();

                new PedidoNeg().Cadastrar(pedido);

                PedidoController controller = new PedidoController();

                // Act
                var actual = controller.Buscar(pedido.Id);
                actual.QtdeItem1 = 5;
                pedido.QtdeItem1 = 5;

                controller.Atualizar(actual);

                actual = controller.Buscar(actual.Id);
                // Assert
                Assert.AreEqual(actual.QtdeItem1, pedido.QtdeItem1);

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [TestMethod]
        public void ListarPedidos()
        {
            try
            {
                var pedido = CriaMockPedido();

                new PedidoNeg().Cadastrar(pedido);

                PedidoController controller = new PedidoController();

                // Act
                var actual = controller.Listar() as JsonResult;
                var list = (IList<PedidoModel>)actual.Data;
                
                // Assert
                CollectionAssert.Contains(list.ToList(), pedido);

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private PedidoModel CriaMockPedido()
        {
            var pedido = new PedidoModel();

            pedido.Email = "email@test.com";
            pedido.Item1 = "Camisa";
            pedido.QtdeItem1 = 2;
            pedido.Item2 = "Bermuda";
            pedido.QtdeItem2 = 3;

            return pedido;

        }

      
}

    
}
