﻿using CarrinhoCompras.Models.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarrinhoCompras.Models.Repositorio
{
    public class PedidoRepositorio
    {
        private static List<PedidoModel> _listPedidos;

       
        public PedidoRepositorio()
        {            
            if (_listPedidos == null)
            {
                _listPedidos = new List<PedidoModel>();
            }
        }
        
        public PedidoModel GetById(int id)
        {
            return _listPedidos.SingleOrDefault(m => m.Id == id);
        }

        
        public void Cadastrar(PedidoModel pedido)
        {
           
            var id = 1;

            while (_listPedidos.Any(x => x.Id == id))
                id++;

            pedido.Id = id;

            
            _listPedidos.Add(pedido);
        }

        
        public void Atualizar(PedidoModel pedido)
        {
           
            var pedidoAnterior = GetById(pedido.Id);
            if (pedidoAnterior != null)
            {
               
                foreach (var propertyInfo in typeof(PedidoModel)
    .GetProperties().Where(x => x.Name != "Id"))
                {
                   
                    propertyInfo.SetValue(pedidoAnterior, propertyInfo.GetValue(pedido));
                }
            }
        }
      
        public void Deletar(int id)
        {
           
            var obj = GetById(id);

       
            _listPedidos.Remove(obj);
        }

        public IEnumerable<PedidoModel> Listar()
        {
          
            return _listPedidos;
        }
    }
}