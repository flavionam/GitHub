﻿using CarrinhoCompras.Models.Model;
using CarrinhoCompras.Models.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarrinhoCompras.Models.Negocio
{
    public class PedidoNeg
    {
        public void Cadastrar(PedidoModel Pedido)
        {
            new PedidoRepositorio().Cadastrar(Pedido);
        }

        public void Atualizar(PedidoModel Pedido)
        {
            new PedidoRepositorio().Atualizar(Pedido);
        }

        public void Deletar(int idPedido)
        {
            new PedidoRepositorio().Deletar(idPedido);
        }

        public void EnviarEmail(int idPedido)
        {
            var pedido = GetById(idPedido);

            MetodoEnviarEmail(pedido);
        }

        private void MetodoEnviarEmail(PedidoModel pedido)
        {
            
        }

        public PedidoModel GetById(int id)
        {
            return new PedidoRepositorio().GetById(id);
        }
        public IEnumerable<PedidoModel> Listar()
        {
            return new PedidoRepositorio().Listar();
        }
    }
}