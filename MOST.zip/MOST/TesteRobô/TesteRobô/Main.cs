﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobotTest
{
    public partial class TestForm : Form
    {
        List<SearchResult> searchResultsList = new List<SearchResult>();
        string bingUrl = "http://www.bing.com/";

        public TestForm()
        {
            InitializeComponent();
        }

        private void TestBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                Execute();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Execute()
        {
            SearchForABSCard();

            SearchForResults();
        }

        private void SearchForResults()
        {
            try
            {
                if (TestBrowser.Document.Url.ToString().Contains("http://www.bing.com/search?q="))
                {
                    var resultsElements = TestBrowser.Document.GetElementById("b_results").Children;
                    

                    foreach (HtmlElement result in resultsElements)
                    {
                        if (result.OuterHtml.Contains("b_algo"))
                        {
                            var title = result.Children[0].InnerText.Trim().Replace(Environment.NewLine, string.Empty);
                            var url = result.Children[1].Children[0].InnerText.Trim().Replace(Environment.NewLine, string.Empty);
                            var description = result.Children[1].Children[1].InnerText.Trim().Replace(Environment.NewLine, string.Empty);

                            var newSearchResult = new SearchResult
                            {
                                Title = title,
                                Url = url,
                                Description = description
                            };

                            searchResultsList.Add(newSearchResult);
                        }
                    }

                    WriteDataInCsv();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in SearchForResults: " + ex.Message);
            }
        }

        public void SearchForABSCard()
        {
            try
            {
                if (TestBrowser.Document.Url.Equals("http://www.bing.com/"))
                {
                    var searchBox = TestBrowser.Document.GetElementById("sb_form_q");                    
                    searchBox.InnerText = "ABSCard Gestão de Benefícios";

                    var searchButton = TestBrowser.Document.GetElementById("sb_form_go");
                    searchButton.InvokeMember("click");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in SearchForABSCard: " + ex.Message);
            }
        }

        public void WriteDataInCsv()
        {
            var sw = new StreamWriter(Application.StartupPath + "\\SearchResults.csv");

            foreach (var searchResult in searchResultsList)
            {
                sw.WriteLine("{0};{1};{2}", searchResult.Title, searchResult.Url, searchResult.Description);
            }
            sw.Dispose();

            Process.Start("notepad.exe", Application.StartupPath + "\\SearchResults.csv");
            Close();
        }

    }
}
