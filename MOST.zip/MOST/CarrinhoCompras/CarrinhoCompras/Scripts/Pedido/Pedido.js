﻿



function LimparFormulario() {

    $('#formDados').each(function () {
        this.reset();
    });
}


function Mensagem(stringCss, mensagem) {

    $("#mensagem").remove();

    setTimeout(function () {

        $('#formDados').append("<div class='alert alert-" + stringCss + "' id=mensagem role=alert>" + mensagem + "</div>");
    }, 10);
}

function Cadastrar() {
    var dadosSerializados = $('#formDados').serialize();
    $.ajax({
        type: "POST",
        url: "/Pedido/Cadastrar",
        data: dadosSerializados,
        success: function (dadosPedido) {  

            LimparFormulario();
            Mensagem("success", "Cadastrado com Sucesso!");

            if (dadosPedido.length == 0) {
                $('table').addClass('hidden');
            } else {
                $('table').removeClass('hidden');

                $('#tbody').children().remove();
                $(dadosPedido).each(function (i) {
                    var tbody = $('#tbody');
                    var tr = "<tr>";
                    tr += "<td>" + dadosPedido[i].Id;
                    tr += "<td>" + dadosPedido[i].Email;
                    tr += "<td>" + dadosPedido[i].Item1;
                    tr += "<td>" + dadosPedido[i].QtdeItem1;
                    tr += "<td>" + dadosPedido[i].Item2;
                    tr += "<td>" + dadosPedido[i].QtdeItem2;
                    tr += "<td>" + "<button class='btn btn-info' onclick=Editar(" + dadosPedido[i].Id + ")>" + "Editar";
                    tr += "<td>" + "<button class='btn btn-danger' onclick=Deletar(" + dadosPedido[i].Id + ")>" + "Deletar";
                    tr += "<td>" + "<button class='btn btn-primary' onclick=EnviarEmail(" + dadosPedido[i].Id + ")>" + "Enviar e-mail";
                    tbody.append(tr);
                });
            }

        },
        error: function () {
            Mensagem("danger", "Erro ao cadastrar!");
        }
    });
}

function Listar() {

    LimparFormulario();
    $.ajax({
        type: "GET",
        url: "/Pedido/Listar",
        success: function (dadosPedido) {            

            if (dadosPedido.length == 0) {
                $('table').addClass('hidden');
            } else {
                $('table').removeClass('hidden');                  

                $('#tbody').children().remove();
                $(dadosPedido).each(function (i) {
                    var tbody = $('#tbody');
                    var tr = "<tr>";
                    tr += "<td>" + dadosPedido[i].Id;
                    tr += "<td>" + dadosPedido[i].Email;
                    tr += "<td>" + dadosPedido[i].Item1;
                    tr += "<td>" + dadosPedido[i].QtdeItem1;
                    tr += "<td>" + dadosPedido[i].Item2;
                    tr += "<td>" + dadosPedido[i].QtdeItem2;
                    tr += "<td>" + "<button class='btn btn-info' onclick=Editar(" + dadosPedido[i].Id + ")>" + "Editar";
                    tr += "<td>" + "<button class='btn btn-danger' onclick=Deletar(" + dadosPedido[i].Id + ")>" + "Deletar";
                    tr += "<td>" + "<button class='btn btn-primary' onclick=EnviarEmail(" + dadosPedido[i].Id + ")>" + "Enviar e-mail";
                    tbody.append(tr);
                });
            }
        }
    });
}

function Deletar(idPedido) {
    var confirmar = confirm("Deseja Realmente Apagar ?");
    if (confirmar) {
        $.ajax({
            type: 'POST',
            url: "/Pedido/Deletar",
            data: { id: idPedido },
            success: function (dadosPedido) {
             
                Mensagem("success", "Deletado com sucesso!");

                if (dadosPedido.length == 0) {
                    $('table').addClass('hidden');
                } else {
                    $('table').removeClass('hidden');

                    $('#tbody').children().remove();
                    $(dadosPedido).each(function (i) {
                        var tbody = $('#tbody');
                        var tr = "<tr>";
                        tr += "<td>" + dadosPedido[i].Id;
                        tr += "<td>" + dadosPedido[i].Email;
                        tr += "<td>" + dadosPedido[i].Item1;
                        tr += "<td>" + dadosPedido[i].QtdeItem1;
                        tr += "<td>" + dadosPedido[i].Item2;
                        tr += "<td>" + dadosPedido[i].QtdeItem2;
                        tr += "<td>" + "<button class='btn btn-info' onclick=Editar(" + dadosPedido[i].Id + ")>" + "Editar";
                        tr += "<td>" + "<button class='btn btn-danger' onclick=Deletar(" + dadosPedido[i].Id + ")>" + "Deletar";
                        tr += "<td>" + "<button class='btn btn-primary' onclick=EnviarEmail(" + dadosPedido[i].Id + ")>" + "Enviar e-mail";
                        tbody.append(tr);
                    });
                }

            },
            error: function () {
                Mensagem("danger", "Erro ao Deletar!");
            }
        });
    }
}

function Editar(idPedido) {
    $.ajax({
        type: 'POST',
        url: '/Pedido/Editar',
     
        data: { id: idPedido },
        success: function (dados) {
                  
            $('#idPedido').val(dados.Id);
            $('#Email').val(dados.Email);
            $('#Item1').val(dados.Item1);
            $('#QtdeItem1').val(dados.QtdeItem1);
            $('#Item2').val(dados.Item2);
            $('#QtdeItem2').val(dados.QtdeItem2);
                 
            $("#salvar").addClass("hidden");
            $("#atualizar").removeClass("hidden");
        }
    });
}


    function Atualizar() {

        var dadosSerializados = $('#formDados').serialize();
        $.ajax({
            type: "POST",
            url: "/Pedido/Atualizar",

            data: dadosSerializados,
            success: function (dadosPedido) {

                LimparFormulario();
                $("#salvar").removeClass("hidden");
                $("#atualizar").addClass("hidden");

                if (dadosPedido.length == 0) {
                    $('table').addClass('hidden');
                } else {
                    $('table').removeClass('hidden');

                    $('#tbody').children().remove();
                    $(dadosPedido).each(function (i) {
                        var tbody = $('#tbody');
                        var tr = "<tr>";
                        tr += "<td>" + dadosPedido[i].Id;
                        tr += "<td>" + dadosPedido[i].Email;
                        tr += "<td>" + dadosPedido[i].Item1;
                        tr += "<td>" + dadosPedido[i].QtdeItem1;
                        tr += "<td>" + dadosPedido[i].Item2;
                        tr += "<td>" + dadosPedido[i].QtdeItem2;
                        tr += "<td>" + "<button class='btn btn-info' onclick=Editar(" + dadosPedido[i].Id + ")>" + "Editar";
                        tr += "<td>" + "<button class='btn btn-danger' onclick=Deletar(" + dadosPedido[i].Id + ")>" + "Deletar";
                        tr += "<td>" + "<button class='btn btn-primary' onclick=EnviarEmail(" + dadosPedido[i].Id + ")>" + "Enviar e-mail";
                        tbody.append(tr);
                    });
                }             

            },

            error: function myfunction() {
                alert("Erro!");
            }
        });
}

function EnviarEmail(idPedido) {
   
        $.ajax({
            type: 'GET',
            url: "/Pedido/EnviarEmail",
            data: { id: idPedido },
            success: function () {
                Mensagem("success", "E-mail enviado com sucesso!");
            },
            error: function () {
                Mensagem("danger", "Erro ao enviar e-mail!");
            }
        });
    
}